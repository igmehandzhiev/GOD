#include "Simulator.h"
using namespace std;
int main()
{
	Simulator simulator;
	simulator.Run();
	system("pause");
	return 0;

}
#ifndef ENUM_H
#define ENUM_H
enum  State { Moving, Attacking, Eating, SearchFood, Sleeping, Analyzing };

enum EntityType { entity, animal, human, god };
#endif